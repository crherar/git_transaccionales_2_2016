#ifndef _DBM_CONECTAR_H
#define _DBM_CONECTAR_H
#include "modelo.h"

//int db_conectar(char *base_de_datos, char *usuario, char *pass);
int db_conectar();
void db_close();
void db_commit();


#endif




































//int db_connect(char *base_de_datos, char *usuario, char *pass);
